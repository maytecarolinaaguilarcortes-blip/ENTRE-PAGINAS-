# Entre Páginas — proyecto Android (base offline)

Este paquete prepara el HTML actual como contenido local de una aplicación Android con Capacitor. No contiene un APK compilado.

## Qué incluye
- `www/index.html`: versión de la app basada en la última versión disponible (v7), conservando el diseño y las funciones del HTML.
- `package.json` y `capacitor.config.json`: configuración inicial para crear el contenedor Android.

## Requisito importante sobre los datos
La app actual guarda su estado en `localStorage` con la clave `entrePaginas_v1`. Los datos del archivo abierto desde Descargas en Chrome (`content://...`) **no se copian automáticamente** a la app Android: Android WebView tendrá su propio almacenamiento. Antes de usar la APK como biblioteca principal hay que exportar un respaldo JSON desde la versión antigua e importarlo en la app nueva. Si la pantalla de la versión actual no permite hacerlo, no borres datos del navegador ni desinstales versiones anteriores; primero habrá que añadir/usar una vía de recuperación de datos.

## Cómo generar el APK en un computador
1. Instala Node.js LTS y Android Studio.
2. Descomprime esta carpeta.
3. En una terminal, entra en `entre_paginas_android` y ejecuta:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. En Android Studio, espera a que termine la sincronización de Gradle e instala los componentes del SDK que solicite.
5. Para probar en un teléfono conectado por USB: pulsa **Run**. Para crear un APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Instala el APK de prueba y activa modo avión. Comprueba navegación, alta/edición de libros, portadas guardadas localmente, notas y estadísticas.

## Qué funciona sin internet
El HTML se incluye dentro de la app, así que la interfaz principal no necesita descargar una web. Las búsquedas de libros, portadas remotas y servicios externos sí necesitan internet mientras se consultan; sus resultados deben guardarse localmente para poder verse después sin conexión.

## Estado actual
Esto es un proyecto inicial de empaquetado, no una APK final ni una certificación de que todos los botones ya funcionen. Antes de darlo por terminado hay que probar y corregir los errores de JavaScript en un dispositivo Android y verificar la migración de los datos.


## Compilar usando solo el celular (GitHub Actions)
Este paquete incluye `.github/workflows/android.yml`. Desde el navegador del teléfono:
1. Inicia sesión o crea una cuenta en GitHub.
2. Crea un repositorio nuevo. Para facilitar el flujo, puede ser privado, pero revisa los límites de minutos de Actions de tu cuenta; un repositorio público también permite Actions.
3. Sube el contenido de este ZIP al nivel raíz del repositorio (incluida la carpeta oculta `.github/workflows` y su archivo `android.yml`; si la interfaz móvil no permite subir carpetas, crea el archivo del workflow desde GitHub usando la ruta `.github/workflows/android.yml`).
4. Abre la pestaña **Actions**, selecciona **Construir APK de Entre Páginas** y pulsa **Run workflow**. También se ejecutará al subir cambios a `main`.
5. Cuando termine en verde, entra a la ejecución, busca **Artifacts** y descarga `Entre-Paginas-debug-apk`. Descomprime el ZIP del artefacto para obtener `app-debug.apk`, y ábrelo para instalarlo.
6. Android puede pedir permiso para instalar aplicaciones desconocidas para el navegador/gestor de archivos. Habilítalo solo para la app que estés usando para instalar y desactívalo después si lo prefieres.

La APK de debug es para pruebas personales, no una publicación de Play Store. No compartas repositorios ni artefactos que contengan datos personales. Este workflow compila el HTML empaquetado; no repara automáticamente errores internos de la aplicación ni migra el `localStorage` de Chrome.
